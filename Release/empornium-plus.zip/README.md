# empornium-plus
Empornium Plus

Modifies the Empornium torrents page so that the summary image of the torrent is displayed instead of the useless icon. You can now see what the torrent is like without hovering over the item.

![screenshot2](https://user-images.githubusercontent.com/110262393/183752019-ae2ea9ee-1c61-459e-b9c4-deee0e0a3fa6.PNG)

To install:

1) Download the release zip: https://github.com/jimproms/empornium-plus/raw/main/Release/empornium-plus.zip
2) Unzip to somewhere on your computer
3) Go to chrome://extensions/ in Chrome and turn on the Developer option in the top right
4) Click "Load Unpacked" and browse to where you unzipped the zip file
5) Refresh your Empornium page!

![Chrome](https://user-images.githubusercontent.com/110262393/183752612-0fe1d456-8358-406f-9c0e-28d22f95a9bc.PNG)

